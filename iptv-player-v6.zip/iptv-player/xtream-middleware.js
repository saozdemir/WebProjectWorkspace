// Vite dev sunucusuna gömülü ara katmanlar — TEK BAĞLANTI TASARIMI:
// IPTV hesapları genellikle tek eşzamanlı bağlantıya izin verir; bu yüzden
// sunucuya aynı anda asla birden fazla istek açılmaz.
//
// 1) /hlsproxy   — Canlı yayın (m3u8) proxy'si
// 2) /mediainfo  — TEK ffprobe sorgusu: süre + altyazı izleri + ses izleri
//                  (oynatma başlamadan önce çağrılır, sonra kapanır)
// 3) /transcode  — ffmpeg: ses dönüştürme + İSTENİRSE altyazıyı da AYNI
//                  süreçte geçici VTT dosyasına çıkarır (?sub=N&subkey=K)
// 4) /subfile    — büyümekte olan VTT dosyasını tarayıcıya akıtır
//                  (IPTV sunucusuna bağlantı AÇMAZ, yerel dosyadan okur)

import { spawn } from 'node:child_process'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'

const UA = 'VLC/3.0.20 LibVLC/3.0.20'
const prox = (abs) => `/hlsproxy?url=${encodeURIComponent(abs)}`

const TEXT_SUB_CODECS = new Set(['subrip', 'srt', 'ass', 'ssa', 'webvtt', 'mov_text', 'text'])

const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'iptv-subs-'))
const subJobs = new Map() // subkey -> { file, done }

function rewritePlaylist(text, baseUrl) {
  return text.split('\n').map((line) => {
    const t = line.trim()
    if (!t) return line
    if (t.startsWith('#')) {
      return line.replace(/URI="([^"]+)"/g,
        (_, u) => `URI="${prox(new URL(u, baseUrl).href)}"`)
    }
    return prox(new URL(t, baseUrl).href)
  }).join('\n')
}

function runFfprobe(target, extraArgs, onDone) {
  const fp = spawn('ffprobe', ['-v', 'error', '-user_agent', UA, ...extraArgs, '-of', 'json', target])
  let out = ''
  fp.stdout.on('data', (d) => { out += d })
  fp.on('error', (e) => onDone(e, null))
  fp.on('close', () => {
    try { onDone(null, JSON.parse(out)) } catch (e) { onDone(e, null) }
  })
}

export default function xtreamMiddleware() {
  return {
    name: 'xtream-middleware',
    configureServer(server) {
      // ---------- 1) Canlı yayın proxy'si ----------
      server.middlewares.use('/hlsproxy', async (req, res) => {
        try {
          const target = new URL(req.url, 'http://x').searchParams.get('url')
          if (!target) { res.statusCode = 400; return res.end('url parametresi gerekli') }

          const r = await fetch(target, { headers: { 'User-Agent': UA } })
          const ct = r.headers.get('content-type') || ''

          if (target.includes('.m3u8') || ct.includes('mpegurl')) {
            const text = await r.text()
            res.setHeader('Content-Type', 'application/vnd.apple.mpegurl')
            res.setHeader('Cache-Control', 'no-store')
            res.end(rewritePlaylist(text, r.url))
          } else {
            res.statusCode = r.status
            res.setHeader('Content-Type', ct || 'video/mp2t')
            res.end(Buffer.from(await r.arrayBuffer()))
          }
        } catch (e) {
          res.statusCode = 502
          res.end('proxy hatası: ' + e.message)
        }
      })

      // ---------- 2) Tek sorguda tüm bilgi: süre + izler ----------
      server.middlewares.use('/mediainfo', (req, res) => {
        const target = new URL(req.url, 'http://x').searchParams.get('url')
        if (!target) { res.statusCode = 400; return res.end('url parametresi gerekli') }

        runFfprobe(target, ['-show_streams', '-show_format'], (err, d) => {
          if (res.writableEnded) return
          res.setHeader('Content-Type', 'application/json')
          if (err) {
            res.statusCode = 500
            return res.end(JSON.stringify({ duration: 0, subtitles: [], audios: [] }))
          }

          const subtitles = []
          const audios = []
          let sIdx = -1 // 0:s:N — sadece altyazı izleri arasında sayılır
          let aIdx = -1 // 0:a:N — sadece ses izleri arasında sayılır
          for (const st of d.streams || []) {
            const lang = st.tags?.language || ''
            const title = st.tags?.title || ''
            if (st.codec_type === 'audio') {
              aIdx++
              audios.push({
                i: aIdx,
                label: [lang, title].filter(Boolean).join(' — ') || `Ses ${aIdx + 1}`,
              })
            } else if (st.codec_type === 'subtitle') {
              sIdx++
              if (!TEXT_SUB_CODECS.has(st.codec_name)) continue // PGS/DVD (bitmap) çevrilemez
              subtitles.push({
                i: sIdx,
                label: [lang, title].filter(Boolean).join(' — ') || `Altyazı ${sIdx + 1}`,
              })
            }
          }
          res.end(JSON.stringify({
            duration: parseFloat(d.format?.duration || 0) || 0,
            subtitles,
            audios,
          }))
        })
      })

      // ---------- 3) Dönüştürme (+ aynı süreçte altyazı çıkarma) ----------
      // ?url=...&ss=SANIYE&audio=N&sub=N&subkey=RASTGELE
      server.middlewares.use('/transcode', (req, res) => {
        const q = new URL(req.url, 'http://x').searchParams
        const target = q.get('url')
        const ss = Math.max(0, parseInt(q.get('ss') || '0', 10) || 0)
        const audio = Math.max(0, parseInt(q.get('audio') || '0', 10) || 0)
        const sub = parseInt(q.get('sub') ?? '-1', 10)
        const subkey = q.get('subkey') || ''
        if (!target) { res.statusCode = 400; return res.end('url parametresi gerekli') }
        if (subkey && !/^[a-z0-9]+$/i.test(subkey)) { res.statusCode = 400; return res.end('geçersiz subkey') }

        res.setHeader('Content-Type', 'video/mp4')
        res.setHeader('Cache-Control', 'no-store')

        const args = ['-nostdin', '-y', '-loglevel', 'error', '-user_agent', UA]
        if (ss > 0) args.push('-ss', String(ss))
        args.push(
          '-i', target,
          // Çıkış 1: video akışı (tarayıcıya)
          '-map', '0:v:0', '-map', `0:a:${audio}?`,
          '-sn', '-dn',
          '-c:v', 'copy',
          '-c:a', 'aac', '-b:a', '192k',
          '-movflags', 'frag_keyframe+empty_moov+default_base_moof',
          '-f', 'mp4', 'pipe:1',
        )

        // Çıkış 2: aynı süreçte altyazı → geçici VTT (ekstra bağlantı YOK)
        let job = null
        if (sub >= 0 && subkey) {
          const vttPath = path.join(tmpDir, subkey + '.vtt')
          job = { file: vttPath, done: false }
          subJobs.set(subkey, job)
          args.push('-map', `0:s:${sub}`, '-c:s', 'webvtt', '-f', 'webvtt', vttPath)
        }

        const ff = spawn('ffmpeg', args)
        ff.on('error', (e) => {
          if (!res.headersSent) {
            res.statusCode = 500
            res.setHeader('Content-Type', 'text/plain; charset=utf-8')
          }
          res.end('ffmpeg çalıştırılamadı: ' + e.message)
          console.error('[transcode] ffmpeg başlatılamadı:', e.message)
        })
        ff.stderr.on('data', (d) => console.error('[ffmpeg]', d.toString().trim()))
        ff.stdout.pipe(res)

        const finishJob = () => {
          if (!job) return
          job.done = true
          // 10 dk sonra geçici dosyayı temizle
          setTimeout(() => {
            subJobs.delete(subkey)
            fs.unlink(job.file, () => {})
          }, 10 * 60 * 1000)
        }
        ff.on('close', finishJob)
        res.on('close', () => { ff.kill('SIGKILL'); finishJob() })
      })

      // ---------- 4) Büyüyen VTT dosyasını akıt ----------
      server.middlewares.use('/subfile', (req, res) => {
        const key = new URL(req.url, 'http://x').searchParams.get('key') || ''
        if (!/^[a-z0-9]+$/i.test(key)) { res.statusCode = 400; return res.end() }

        res.setHeader('Content-Type', 'text/vtt; charset=utf-8')
        res.setHeader('Cache-Control', 'no-store')

        let pos = 0
        let waitedForJob = 0
        const timer = setInterval(() => {
          const job = subJobs.get(key)
          if (!job) {
            // transcode henüz başlamamış olabilir; biraz bekle
            waitedForJob += 700
            if (waitedForJob > 30000) { clearInterval(timer); res.end('WEBVTT\n') }
            return
          }
          try {
            const st = fs.statSync(job.file)
            if (st.size > pos) {
              const fd = fs.openSync(job.file, 'r')
              const buf = Buffer.alloc(st.size - pos)
              fs.readSync(fd, buf, 0, buf.length, pos)
              fs.closeSync(fd)
              pos = st.size
              res.write(buf)
            } else if (job.done) {
              clearInterval(timer)
              res.end()
            }
          } catch {
            if (job.done) { clearInterval(timer); res.end() }
          }
        }, 700)
        res.on('close', () => clearInterval(timer))
      })
    },
  }
}
