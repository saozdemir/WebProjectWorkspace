// Tüm hesap bilgileri tek yerde — değişirse sadece burayı güncelle.
export const XT = {
  base: '/xtream',                    // Vite proxy → http://santralbaba2.xyz
  direct: 'http://santralbaba2.xyz',  // VLC/mpv gibi harici oynatıcı linkleri için
  user: '91DRuo15',
  pass: 'u76rOuCF',
}

export const api = (action, extra = '') =>
  `${XT.base}/player_api.php?username=${XT.user}&password=${XT.pass}&action=${action}${extra}`

// ---- Harici oynatıcıya kopyalanacak doğrudan linkler ----
export const directLive = (id) => `${XT.direct}/live/${XT.user}/${XT.pass}/${id}.ts`
export const directVod = (id, ext) => `${XT.direct}/movie/${XT.user}/${XT.pass}/${id}.${ext || 'mp4'}`
export const directSeries = (id, ext) => `${XT.direct}/series/${XT.user}/${XT.pass}/${id}.${ext || 'mp4'}`

// ---- Tarayıcı içi oynatma ----
// Canlı: akıllı HLS proxy'si üzerinden (yönlendirme + CORS çözümü)
export const liveUrl = (id) =>
  `/hlsproxy?url=${encodeURIComponent(`${XT.direct}/live/${XT.user}/${XT.pass}/${id}.m3u8`)}`

// Film/dizi: önce doğrudan (basit proxy'den) denenir — MP4+AAC olanlar sarma dahil tam çalışır
export const vodUrl = (id, ext) => `${XT.base}/movie/${XT.user}/${XT.pass}/${id}.${ext || 'mp4'}`
export const seriesUrl = (id, ext) => `${XT.base}/series/${XT.user}/${XT.pass}/${id}.${ext || 'mp4'}`

// Ses yoksa / dosya açılmazsa: ffmpeg ile anlık dönüştürme
export const transcodeUrl = (directLink) =>
  `/transcode?url=${encodeURIComponent(directLink)}`
