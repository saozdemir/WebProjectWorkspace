import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import xtreamMiddleware from './xtream-middleware.js'

export default defineConfig({
  plugins: [react(), xtreamMiddleware()],
  server: {
    port: 5173,
    proxy: {
      // player_api.php çağrıları ve MP4 film akışları bu basit proxy'den geçer
      '/xtream': {
        target: 'http://santralbaba2.xyz',
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/xtream/, ''),
        followRedirects: true,
      },
    },
  },
})
