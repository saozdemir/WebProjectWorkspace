// Vite dev sunucusuna gömülü iki ara katman:
//
// 1) /hlsproxy   — Canlı yayın (m3u8) proxy'si:
//    - Sunucunun 302 yönlendirmelerini takip eder
//    - Playlist içindeki mutlak segment adreslerini kendi üzerinden
//      geçecek şekilde yeniden yazar (CORS/mixed-content çözümü)
//    - Panelin kabul ettiği bir User-Agent gönderir
//
// 2) /transcode  — Ses dönüştürme (ffmpeg gerekir):
//    - Görüntüye dokunmadan (copy) sesi anlık AAC'ye çevirir
//    - AC3/DTS sesli filmler ve MKV dosyalar tarayıcıda oynar hale gelir

import { spawn } from 'node:child_process'

const UA = 'VLC/3.0.20 LibVLC/3.0.20'
const prox = (abs) => `/hlsproxy?url=${encodeURIComponent(abs)}`

function rewritePlaylist(text, baseUrl) {
  return text.split('\n').map((line) => {
    const t = line.trim()
    if (!t) return line
    if (t.startsWith('#')) {
      // #EXT-X-KEY gibi satırlardaki URI="..." kısımları
      return line.replace(/URI="([^"]+)"/g,
        (_, u) => `URI="${prox(new URL(u, baseUrl).href)}"`)
    }
    return prox(new URL(t, baseUrl).href)
  }).join('\n')
}

export default function xtreamMiddleware() {
  return {
    name: 'xtream-middleware',
    configureServer(server) {
      // ---------- 1) Canlı yayın proxy'si ----------
      server.middlewares.use('/hlsproxy', async (req, res) => {
        try {
          const target = new URL(req.url, 'http://x').searchParams.get('url')
          if (!target) { res.statusCode = 400; return res.end('url parametresi gerekli') }

          const r = await fetch(target, { headers: { 'User-Agent': UA } })
          const ct = r.headers.get('content-type') || ''

          if (target.includes('.m3u8') || ct.includes('mpegurl')) {
            const text = await r.text()
            res.setHeader('Content-Type', 'application/vnd.apple.mpegurl')
            res.setHeader('Cache-Control', 'no-store')
            // r.url = yönlendirme sonrası GERÇEK adres; göreli yollar buna göre çözülür
            res.end(rewritePlaylist(text, r.url))
          } else {
            res.statusCode = r.status
            res.setHeader('Content-Type', ct || 'video/mp2t')
            res.end(Buffer.from(await r.arrayBuffer()))
          }
        } catch (e) {
          res.statusCode = 502
          res.end('proxy hatası: ' + e.message)
        }
      })

      // ---------- 2) Ses dönüştürme (ffmpeg) ----------
      server.middlewares.use('/transcode', (req, res) => {
        const target = new URL(req.url, 'http://x').searchParams.get('url')
        if (!target) { res.statusCode = 400; return res.end('url parametresi gerekli') }

        res.setHeader('Content-Type', 'video/mp4')
        res.setHeader('Cache-Control', 'no-store')

        const ff = spawn('ffmpeg', [
          '-nostdin', '-loglevel', 'error',
          '-user_agent', UA,
          '-i', target,
          '-c:v', 'copy',                 // görüntüye dokunma (işlemciyi yormaz)
          '-c:a', 'aac', '-b:a', '192k',  // sesi AAC'ye çevir
          '-movflags', 'frag_keyframe+empty_moov+default_base_moof',
          '-f', 'mp4', 'pipe:1',
        ])

        ff.on('error', (e) => {
          // ffmpeg kurulu değilse buraya düşer
          if (!res.headersSent) {
            res.statusCode = 500
            res.setHeader('Content-Type', 'text/plain; charset=utf-8')
          }
          res.end('ffmpeg çalıştırılamadı: ' + e.message +
            '\nffmpeg kurulu mu? (Windows: winget install Gyan.FFmpeg)')
          console.error('[transcode] ffmpeg başlatılamadı:', e.message)
        })

        ff.stderr.on('data', (d) => console.error('[ffmpeg]', d.toString().trim()))
        ff.stdout.pipe(res)
        res.on('close', () => ff.kill('SIGKILL'))
      })
    },
  }
}
