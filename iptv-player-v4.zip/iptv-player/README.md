# IPTV Oynatıcı v4 (React + Vite)

Xtream Codes paneli (santralbaba2.xyz) için tarayıcıda çalışan IPTV oynatıcı.
Bu sürümde canlı yayın ve ses sorunları için düzeltmeler gömülüdür.

## Kurulum

Gerekenler: **Node.js 18+** ve **ffmpeg** (ses dönüştürme için).

ffmpeg kurulumu:
- Windows: `winget install Gyan.FFmpeg` (sonra terminali kapatıp yeniden aç)
- CachyOS / Arch: `sudo pacman -S ffmpeg`

Ardından:

```bash
cd iptv-player
npm install
npm run dev
```

Tarayıcıda **http://localhost:5173** — başka bir şey çalıştırmana gerek yok;
proxy ve dönüştürücü Vite'ın içine gömülü.

## Bu sürümde ne değişti?

**Canlı yayın:** Xtream sunucuları canlı m3u8 isteğini genellikle başka bir
sunucuya yönlendirir ve playlist içindeki adresler oraya işaret eder; tarayıcı
bu adreslere erişemediği için yayın hiç açılmıyordu. Yeni `/hlsproxy` ara
katmanı yönlendirmeleri takip eder ve playlist'i yeniden yazarak her şeyi
kendi üzerinden geçirir. Ayrıca panelin kabul ettiği bir User-Agent gönderir.

**Ses:** IPTV filmlerinin sesi çoğunlukla AC3/DTS (Dolby) formatındadır ve
tarayıcılar bu ses codec'lerini çözemez — ses simgesinin pasif görünmesinin
sebebi buydu (çözülebilir ses izi yok). Yeni `/transcode` ara katmanı ffmpeg
ile görüntüye dokunmadan sesi anlık AAC'ye çevirir.

## Oynatma mantığı

1. Film/dizi önce **normal modda** açılır — dosya MP4+AAC ise sarma dahil
   her şey tam çalışır.
2. Dosya hiç açılmazsa (ör. MKV) otomatik olarak **dönüştürme moduna** geçilir.
3. Görüntü var ama ses yoksa oynatıcıdaki **"🔊 Ses yok? Dönüştür"** düğmesine
   bas — ses AAC'ye çevrilerek yeniden başlar.
4. Canlı yayın HLS ile açılır; açılmazsa otomatik olarak dönüştürme
   modundan (.ts akışı) denenir.

## Bilinen sınırlar

- Dönüştürme modunda ileri-geri sarma sınırlıdır (akış anlık üretilir).
- Görüntü HEVC (H.265) kodlanmışsa Chrome oynatmayabilir — bu durumda
  "Linki kopyala" ile VLC/mpv kullan (`mpv "link"` yeterli).
- Proxy'ler Vite dev sunucusunda çalışır; uygulamayı statik hosting'e
  atarsan çalışmaz, `npm run dev` ile kullan.
- Hesap bilgileri `src/config.js` dosyasında.

## Sorun giderme

- Ses düğmesi sonrası da ses yoksa terminalde `[ffmpeg]` satırlarına bak —
  ffmpeg kurulu değilse orada görürsün.
- Bir canlı kanal yine açılmazsa terminalden şunu çalıştırıp çıktıyı incele:
  `curl -iL "http://santralbaba2.xyz/live/91DRuo15/u76rOuCF/KANAL_ID.m3u8"`

## v3'te yeni: dönüştürme modunda sarma

Dönüştürme modunda videonun altında turuncu bir sarma çubuğu belirir
(süre ffprobe ile öğrenilir). Çubuğu sürükleyip bıraktığında akış o
dakikadan sunucuda yeniden başlatılır (`ffmpeg -ss`). Videonun kendi
ilerleme çubuğu bu modda çalışmaz — sarma için turuncu çubuğu kullan.
Ayrıca MKV'lerdeki altyazı izleri artık düşürülüyor; bu izler bazı
bölümlerde dönüştürmeyi tamamen bozabiliyordu.

## v4'te yeni: altyazı seçimi

Film ve dizi oynatıcısında videonun altında "Altyazı" seçici vardır:

- **Gömülü izler:** Dosyanın içindeki metin tabanlı altyazı izleri (Türkçe,
  İngilizce vb.) otomatik listelenir; seçtiğin iz ffmpeg ile WebVTT'ye
  çevrilip gösterilir. Görüntü tabanlı (PGS/DVD) altyazılar çevrilemediği
  için listede görünmez.
- **.srt yükle:** Dosyada uygun iz yoksa internetten indirdiğin .srt
  dosyasını yükleyebilirsin; tarayıcıda anında VTT'ye çevrilir.
- Dönüştürme modunda ileri sarınca altyazı zamanları da aynı noktaya
  kaydırılır — kayma olmaz.
- Not: Gömülü altyazı seçildiğinde ffmpeg dosyayı arka planda okuyarak
  altyazıyı çıkarır; ileriki dakikaların altyazısı birkaç saniye gecikmeli
  gelebilir. Dönüştürme modunda sardığında çıkarma o noktadan yeniden
  başladığı için izlediğin yerin altyazısı hazır olur.
