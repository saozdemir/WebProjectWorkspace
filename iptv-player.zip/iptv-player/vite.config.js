import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// Panel HTTP çalıştığı ve CORS başlığı göndermediği için
// tüm istekleri (API + yayın akışı) bu proxy üzerinden geçiriyoruz.
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      '/xtream': {
        target: 'http://santralbaba2.xyz',
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/xtream/, ''),
        // Bazı Xtream sunucuları yayını başka bir sunucuya yönlendirir;
        // yönlendirmeleri proxy'nin takip etmesi için:
        followRedirects: true,
      },
    },
  },
})
