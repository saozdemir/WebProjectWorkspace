# IPTV Oynatıcı (React + Vite)

Xtream Codes paneli (santralbaba2.xyz) için tarayıcıda çalışan IPTV oynatıcı.

## Kurulum

Node.js 18+ kurulu olmalı.

```bash
cd iptv-player
npm install
npm run dev
```

Tarayıcıda **http://localhost:5173** adresini aç.

## Neden proxy var?

Panel HTTP (şifresiz) çalışıyor ve CORS başlığı göndermiyor. Tarayıcı bu
yüzden sayfadan doğrudan istek atılmasına izin vermez. `vite.config.js`
içindeki proxy, tüm `/xtream/...` isteklerini sunucuya senin bilgisayarın
üzerinden iletir; hem API hem yayın bu yoldan geçer. Bu nedenle uygulama
`npm run dev` ile çalışırken sorunsuzdur — statik hosting'e (Netlify vb.)
atarsan proxy olmadığı için çalışmaz.

## Özellikler

- 3 sekme: Canlı TV / Filmler / Diziler
- Her sekmede anlık arama (Türkçe karakter duyarlı)
- Kategori (grup) filtresi
- Kanal logoları ve film/dizi afişleri
- Dizilerde sezon → bölüm gezinme
- Canlı yayınlar hls.js ile tarayıcıda oynar
- "Linki kopyala" düğmesi: yayın tarayıcıda açılmazsa doğrudan linki
  VLC veya mpv'ye yapıştırabilirsin (`mpv "link"` yeterli)

## Bilinen sınırlar

- **MKV filmler/bölümler** tarayıcının video etiketinde çoğu zaman oynamaz
  (tarayıcılar MKV kapsayıcısını desteklemez). Bu durumda oynatıcıdaki
  "Linki kopyala" düğmesini kullanıp VLC/mpv ile aç. MP4 olanlar tarayıcıda oynar.
- Bazı Xtream sunucuları yayını başka bir sunucuya yönlendirir; nadiren
  bir kanal tarayıcıda açılmayabilir — yine VLC/mpv çözümdür.
- Hesap bilgileri `src/config.js` dosyasında; değişirse sadece orayı güncelle.
