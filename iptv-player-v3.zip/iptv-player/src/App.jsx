import { useEffect, useMemo, useRef, useState } from 'react'
import Hls from 'hls.js'
import {
  api, liveUrl, vodUrl, seriesUrl, transcodeUrl,
  directLive, directVod, directSeries,
} from './config.js'

const TABS = [
  { key: 'live', label: 'Canlı TV' },
  { key: 'vod', label: 'Filmler' },
  { key: 'series', label: 'Diziler' },
]

const LIST_ACTION = { live: 'get_live_streams', vod: 'get_vod_streams', series: 'get_series' }
const CAT_ACTION = { live: 'get_live_categories', vod: 'get_vod_categories', series: 'get_series_categories' }
const RENDER_LIMIT = 300

const fmt = (s) => {
  s = Math.max(0, Math.floor(s))
  const h = Math.floor(s / 3600)
  const m = Math.floor((s % 3600) / 60)
  const sec = s % 60
  return (h ? `${h}:` : '') + `${String(m).padStart(h ? 2 : 1, '0')}:${String(sec).padStart(2, '0')}`
}

// ---------- Video oynatıcı ----------
// mode: 'native'    → dosya olduğu gibi oynar (MP4+AAC ise her şey tam çalışır)
//       'transcode' → ffmpeg sesi AAC'ye çevirir; sarma, üstteki özel çubukla
//                     yapılır (akış istenen saniyeden sunucuda yeniden başlatılır)
function Player({ url, title, directUrl, tcUrl, live, onClose }) {
  const videoRef = useRef(null)
  const [mode, setMode] = useState('native')
  const [offset, setOffset] = useState(0)     // akışın başladığı saniye (-ss)
  const [duration, setDuration] = useState(0) // toplam süre (ffprobe)
  const [cur, setCur] = useState(0)           // görünen konum = offset + video zamanı
  const [seekVal, setSeekVal] = useState(null) // çubuk sürüklenirkenki geçici değer
  const [error, setError] = useState('')
  const [copied, setCopied] = useState(false)

  const src = mode === 'transcode' && tcUrl ? `${tcUrl}&ss=${offset}` : url
  const isHls = src.includes('.m3u8')

  useEffect(() => {
    const video = videoRef.current
    if (!video) return
    setError('')
    let hls

    if (isHls) {
      if (Hls.isSupported()) {
        hls = new Hls({ maxBufferLength: 30 })
        hls.loadSource(src)
        hls.attachMedia(video)
        hls.on(Hls.Events.MANIFEST_PARSED, () => video.play().catch(() => {}))
        hls.on(Hls.Events.ERROR, (_e, data) => {
          if (data.fatal) {
            hls.destroy()
            if (tcUrl && mode === 'native') {
              setMode('transcode')
            } else {
              setError('Yayın tarayıcıda açılamadı. Linki kopyalayıp VLC veya mpv ile dene.')
            }
          }
        })
      } else if (video.canPlayType('application/vnd.apple.mpegurl')) {
        video.src = src
        video.play().catch(() => {})
      } else {
        setError('Tarayıcın HLS oynatmayı desteklemiyor.')
      }
    } else {
      video.src = src
      video.play().catch(() => {})
    }

    return () => { if (hls) hls.destroy(); video.removeAttribute('src'); video.load() }
  }, [src]) // eslint-disable-line react-hooks/exhaustive-deps

  // Dönüştürme moduna geçince toplam süreyi öğren (canlı yayında süre yok)
  useEffect(() => {
    if (mode !== 'transcode' || live || duration > 0) return
    fetch(`/probe?url=${encodeURIComponent(directUrl)}`)
      .then((r) => r.json())
      .then((d) => setDuration(Math.floor(d.duration || 0)))
      .catch(() => {})
  }, [mode]) // eslint-disable-line react-hooks/exhaustive-deps

  // Native modda dosya hiç açılmazsa (ör. MKV) otomatik dönüştürmeye geç
  const onVideoError = () => {
    if (!isHls && tcUrl && mode === 'native') {
      setMode('transcode')
    } else if (mode === 'transcode') {
      setError('Dönüştürme başarısız. npm run dev terminalindeki [ffmpeg] satırına bak; olmuyorsa linki kopyalayıp VLC/mpv ile aç.')
    } else {
      setError('Bu içerik tarayıcıda oynatılamadı. Linki kopyalayıp VLC/mpv ile aç.')
    }
  }

  const applySeek = () => {
    if (seekVal == null) return
    setOffset(seekVal)
    setCur(seekVal)
    setSeekVal(null)
  }

  const copyLink = async () => {
    try {
      await navigator.clipboard.writeText(directUrl)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    } catch { /* pano erişimi yoksa sessizce geç */ }
  }

  return (
    <div className="player-overlay" onClick={onClose}>
      <div className="player-box" onClick={(e) => e.stopPropagation()}>
        <div className="player-head">
          <span className="player-title">{title}</span>
          <div className="player-actions">
            {tcUrl && mode === 'native' && (
              <button className="btn ghost" onClick={() => setMode('transcode')}>
                🔊 Ses yok? Dönüştür
              </button>
            )}
            {mode === 'transcode' && (
              <button
                className="btn ghost"
                onClick={() => { setMode('native'); setOffset(0); setCur(0); setDuration(0) }}
              >
                Normal moda dön
              </button>
            )}
            <button className="btn ghost" onClick={copyLink}>
              {copied ? 'Kopyalandı ✓' : 'Linki kopyala'}
            </button>
            <button className="btn ghost" onClick={onClose}>Kapat ✕</button>
          </div>
        </div>

        <video
          ref={videoRef}
          controls
          autoPlay
          onError={onVideoError}
          onTimeUpdate={(e) => { if (mode === 'transcode') setCur(offset + e.target.currentTime) }}
        />

        {/* Dönüştürme modunda sarma bu çubukla yapılır */}
        {mode === 'transcode' && duration > 0 && (
          <div className="seekbar">
            <span className="time">{fmt(seekVal ?? cur)}</span>
            <input
              type="range"
              min="0"
              max={duration}
              value={seekVal ?? Math.floor(cur)}
              onChange={(e) => setSeekVal(Number(e.target.value))}
              onPointerUp={applySeek}
              onKeyUp={(e) => {
                if (e.key === 'ArrowLeft' || e.key === 'ArrowRight') applySeek()
              }}
            />
            <span className="time">{fmt(duration)}</span>
          </div>
        )}

        {mode === 'transcode' && !error && (
          <div className="player-note">
            {duration > 0
              ? 'Dönüştürme modu: sarmak için üstteki turuncu çubuğu kullan — videonun kendi çubuğu bu modda çalışmaz. Sardıktan sonra 1-2 saniyelik yüklenme normaldir.'
              : 'Dönüştürme modu: ses AAC\'ye çevriliyor.'}
          </div>
        )}
        {error && <div className="player-error">{error}</div>}
      </div>
    </div>
  )
}

// ---------- Dizi detayı (sezon / bölüm) ----------
function SeriesDetail({ series, onBack, onPlay }) {
  const [info, setInfo] = useState(null)
  const [season, setSeason] = useState(null)
  const [error, setError] = useState('')

  useEffect(() => {
    fetch(api('get_series_info', `&series_id=${series.series_id}`))
      .then((r) => r.json())
      .then((data) => {
        setInfo(data)
        const seasons = Object.keys(data.episodes || {})
        if (seasons.length) setSeason(seasons[0])
      })
      .catch(() => setError('Bölüm bilgisi alınamadı.'))
  }, [series.series_id])

  const seasons = info ? Object.keys(info.episodes || {}) : []
  const episodes = info && season ? info.episodes[season] || [] : []

  return (
    <div className="series-detail">
      <div className="series-head">
        <button className="btn ghost" onClick={onBack}>← Dizilere dön</button>
        <h2>{series.name}</h2>
      </div>
      {info?.info?.plot && <p className="series-plot">{info.info.plot}</p>}
      {error && <div className="notice error">{error}</div>}
      {!info && !error && <div className="notice">Bölümler yükleniyor…</div>}

      {seasons.length > 0 && (
        <div className="season-bar">
          {seasons.map((s) => (
            <button
              key={s}
              className={`chip ${s === season ? 'active' : ''}`}
              onClick={() => setSeason(s)}
            >
              Sezon {s}
            </button>
          ))}
        </div>
      )}

      <div className="episode-list">
        {episodes.map((ep) => (
          <button
            key={ep.id}
            className="episode"
            onClick={() => {
              const direct = directSeries(ep.id, ep.container_extension)
              onPlay({
                title: `${series.name} — S${season}B${ep.episode_num} ${ep.title || ''}`,
                url: seriesUrl(ep.id, ep.container_extension),
                directUrl: direct,
                tcUrl: transcodeUrl(direct),
              })
            }}
          >
            <span className="ep-num">{ep.episode_num}</span>
            <span className="ep-title">{ep.title || `Bölüm ${ep.episode_num}`}</span>
            <span className="ep-play">▶</span>
          </button>
        ))}
      </div>
    </div>
  )
}

// ---------- Ana uygulama ----------
export default function App() {
  const [tab, setTab] = useState('live')
  const [items, setItems] = useState({ live: null, vod: null, series: null })
  const [cats, setCats] = useState({ live: [], vod: [], series: [] })
  const [category, setCategory] = useState('all')
  const [query, setQuery] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [playing, setPlaying] = useState(null)       // { title, url, directUrl, tcUrl, live }
  const [openSeries, setOpenSeries] = useState(null) // seçilen dizi

  // Sekme değişince o sekmenin verisini (bir kez) çek
  useEffect(() => {
    setCategory('all')
    setQuery('')
    setOpenSeries(null)
    setError('')
    if (items[tab] !== null) return

    setLoading(true)
    Promise.all([
      fetch(api(LIST_ACTION[tab])).then((r) => r.json()),
      fetch(api(CAT_ACTION[tab])).then((r) => r.json()).catch(() => []),
    ])
      .then(([list, categories]) => {
        setItems((p) => ({ ...p, [tab]: Array.isArray(list) ? list : [] }))
        setCats((p) => ({ ...p, [tab]: Array.isArray(categories) ? categories : [] }))
      })
      .catch(() => setError('Liste alınamadı. Sunucuya erişim olduğundan emin ol ve sayfayı yenile.'))
      .finally(() => setLoading(false))
  }, [tab]) // eslint-disable-line react-hooks/exhaustive-deps

  const filtered = useMemo(() => {
    const list = items[tab] || []
    const q = query.trim().toLocaleLowerCase('tr')
    return list.filter((it) => {
      if (category !== 'all' && String(it.category_id) !== String(category)) return false
      if (q && !(it.name || '').toLocaleLowerCase('tr').includes(q)) return false
      return true
    })
  }, [items, tab, category, query])

  const play = (it) => {
    if (tab === 'live') {
      const direct = directLive(it.stream_id)
      setPlaying({
        title: it.name,
        url: liveUrl(it.stream_id),
        directUrl: direct,
        tcUrl: transcodeUrl(direct),
        live: true,
      })
    } else if (tab === 'vod') {
      const direct = directVod(it.stream_id, it.container_extension)
      setPlaying({
        title: it.name,
        url: vodUrl(it.stream_id, it.container_extension),
        directUrl: direct,
        tcUrl: transcodeUrl(direct),
      })
    } else {
      setOpenSeries(it)
    }
  }

  const icon = (it) => it.stream_icon || it.cover || ''

  return (
    <div className="app">
      <header className="topbar">
        <span className="brand">▸ IPTV</span>
        <nav className="tabs">
          {TABS.map((t) => (
            <button
              key={t.key}
              className={`tab ${tab === t.key ? 'active' : ''}`}
              onClick={() => setTab(t.key)}
            >
              {t.label}
            </button>
          ))}
        </nav>
      </header>

      {openSeries ? (
        <SeriesDetail
          series={openSeries}
          onBack={() => setOpenSeries(null)}
          onPlay={setPlaying}
        />
      ) : (
        <>
          <div className="controls">
            <input
              className="search"
              type="search"
              placeholder={`${TABS.find((t) => t.key === tab).label} içinde ara…`}
              value={query}
              onChange={(e) => setQuery(e.target.value)}
            />
            <select
              className="cat-select"
              value={category}
              onChange={(e) => setCategory(e.target.value)}
            >
              <option value="all">Tüm kategoriler</option>
              {cats[tab].map((c) => (
                <option key={c.category_id} value={c.category_id}>
                  {c.category_name}
                </option>
              ))}
            </select>
          </div>

          {loading && <div className="notice">Liste yükleniyor…</div>}
          {error && <div className="notice error">{error}</div>}
          {!loading && !error && (
            <div className="count">
              {filtered.length} sonuç
              {filtered.length > RENDER_LIMIT && ` — ilk ${RENDER_LIMIT} tanesi gösteriliyor, aramayla daralt`}
            </div>
          )}

          <div className={`grid ${tab === 'live' ? 'rows' : 'cards'}`}>
            {filtered.slice(0, RENDER_LIMIT).map((it) => (
              <button
                key={it.stream_id || it.series_id}
                className="item"
                onClick={() => play(it)}
                title={it.name}
              >
                {icon(it) ? (
                  <img src={icon(it)} alt="" loading="lazy" onError={(e) => (e.target.style.display = 'none')} />
                ) : (
                  <span className="no-img">▸</span>
                )}
                <span className="item-name">{it.name}</span>
                {tab !== 'live' && it.rating ? <span className="rating">★ {it.rating}</span> : null}
              </button>
            ))}
          </div>
        </>
      )}

      {playing && <Player {...playing} onClose={() => setPlaying(null)} />}
    </div>
  )
}
