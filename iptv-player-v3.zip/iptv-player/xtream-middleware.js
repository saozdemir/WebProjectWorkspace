// Vite dev sunucusuna gömülü ara katmanlar:
//
// 1) /hlsproxy   — Canlı yayın (m3u8) proxy'si (yönlendirme takibi + playlist yeniden yazma)
// 2) /transcode  — ffmpeg ile ses dönüştürme; ?ss=SANIYE ile istenen dakikadan başlar
// 3) /probe      — ffprobe ile videonun toplam süresini döner (sarma çubuğu için)

import { spawn } from 'node:child_process'

const UA = 'VLC/3.0.20 LibVLC/3.0.20'
const prox = (abs) => `/hlsproxy?url=${encodeURIComponent(abs)}`

function rewritePlaylist(text, baseUrl) {
  return text.split('\n').map((line) => {
    const t = line.trim()
    if (!t) return line
    if (t.startsWith('#')) {
      return line.replace(/URI="([^"]+)"/g,
        (_, u) => `URI="${prox(new URL(u, baseUrl).href)}"`)
    }
    return prox(new URL(t, baseUrl).href)
  }).join('\n')
}

export default function xtreamMiddleware() {
  return {
    name: 'xtream-middleware',
    configureServer(server) {
      // ---------- 1) Canlı yayın proxy'si ----------
      server.middlewares.use('/hlsproxy', async (req, res) => {
        try {
          const target = new URL(req.url, 'http://x').searchParams.get('url')
          if (!target) { res.statusCode = 400; return res.end('url parametresi gerekli') }

          const r = await fetch(target, { headers: { 'User-Agent': UA } })
          const ct = r.headers.get('content-type') || ''

          if (target.includes('.m3u8') || ct.includes('mpegurl')) {
            const text = await r.text()
            res.setHeader('Content-Type', 'application/vnd.apple.mpegurl')
            res.setHeader('Cache-Control', 'no-store')
            res.end(rewritePlaylist(text, r.url))
          } else {
            res.statusCode = r.status
            res.setHeader('Content-Type', ct || 'video/mp2t')
            res.end(Buffer.from(await r.arrayBuffer()))
          }
        } catch (e) {
          res.statusCode = 502
          res.end('proxy hatası: ' + e.message)
        }
      })

      // ---------- 2) Ses dönüştürme (ffmpeg) ----------
      // ?url=...&ss=1200  → 20. dakikadan başlat (sarma böyle çalışır)
      server.middlewares.use('/transcode', (req, res) => {
        const q = new URL(req.url, 'http://x').searchParams
        const target = q.get('url')
        const ss = Math.max(0, parseInt(q.get('ss') || '0', 10) || 0)
        if (!target) { res.statusCode = 400; return res.end('url parametresi gerekli') }

        res.setHeader('Content-Type', 'video/mp4')
        res.setHeader('Cache-Control', 'no-store')

        const args = ['-nostdin', '-loglevel', 'error', '-user_agent', UA]
        if (ss > 0) args.push('-ss', String(ss)) // -i'den ÖNCE: hızlı, sunucu tarafı atlama
        args.push(
          '-i', target,
          '-map', '0:v:0', '-map', '0:a:0?',  // ilk görüntü + ilk ses izi
          '-sn', '-dn',                        // altyazı/veri izlerini at (MP4 muxer'ı patlatır)
          '-c:v', 'copy',                      // görüntüye dokunma
          '-c:a', 'aac', '-b:a', '192k',       // sesi AAC'ye çevir
          '-movflags', 'frag_keyframe+empty_moov+default_base_moof',
          '-f', 'mp4', 'pipe:1',
        )

        const ff = spawn('ffmpeg', args)

        ff.on('error', (e) => {
          if (!res.headersSent) {
            res.statusCode = 500
            res.setHeader('Content-Type', 'text/plain; charset=utf-8')
          }
          res.end('ffmpeg çalıştırılamadı: ' + e.message)
          console.error('[transcode] ffmpeg başlatılamadı:', e.message)
        })

        ff.stderr.on('data', (d) => console.error('[ffmpeg]', d.toString().trim()))
        ff.stdout.pipe(res)
        res.on('close', () => ff.kill('SIGKILL'))
      })

      // ---------- 3) Süre öğrenme (ffprobe) ----------
      server.middlewares.use('/probe', (req, res) => {
        const target = new URL(req.url, 'http://x').searchParams.get('url')
        if (!target) { res.statusCode = 400; return res.end('url parametresi gerekli') }

        const fp = spawn('ffprobe', [
          '-v', 'error',
          '-user_agent', UA,
          '-show_entries', 'format=duration',
          '-of', 'json',
          target,
        ])

        let out = ''
        fp.stdout.on('data', (d) => { out += d })
        fp.on('error', (e) => {
          res.statusCode = 500
          res.end(JSON.stringify({ duration: 0, error: e.message }))
        })
        fp.on('close', () => {
          if (res.writableEnded) return
          res.setHeader('Content-Type', 'application/json')
          try {
            const d = JSON.parse(out)
            res.end(JSON.stringify({ duration: parseFloat(d.format?.duration || 0) || 0 }))
          } catch {
            res.end(JSON.stringify({ duration: 0 }))
          }
        })
      })
    },
  }
}
